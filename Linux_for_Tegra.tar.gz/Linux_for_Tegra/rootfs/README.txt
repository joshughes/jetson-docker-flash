Download and extract the sample filesystem to this directory.
