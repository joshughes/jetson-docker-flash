#!/bin/bash
#Copyright (c) 2017 NVIDIA Corporation.  All Rights Reserved.
#
#NVIDIA Corporation and its licensors retain all intellectual property and
#proprietary rights in and to this software and related documentation.  Any
#use, reproduction, disclosure or distribution of this software and related
#documentation without an express license agreement from NVIDIA Corporation
#is strictly prohibited.

#
# Generate BL update payload (BUP) for Jetson-TX2 platform
#
# Usage:
#		build_l4t_bup.sh [options] <target_board> <root_device>
#
#		Where the output is file bl_update_payload under directory bootloader
#
#  Examples:
#	1. Place the board in recovery mode and read in fuse level, board id, and
#		then build BUP specifically for this board:
#
#		sudo ./build_l4t_bup.sh jetson-tx2 mmcblk0p1
#
#	2. Create BUP image completely offline by providing fuse level, board id
#		through environment variables.
#
#		sudo FAB=B00 BOARDID=3310 FUSELEVEL=fuselevel_production ./build_l4t_bup.sh jetson-tx2 mmcblk0p1
#
#	3. Create multi-spec BUP image that can be used to update BLs for different FAB tx2 boards.
#		a. Clean BUP buffer
#			sudo FAB=000 ./build_l4t_bup.sh -r --clean-up jetson-tx2 mmcblk0p1
#
#		b. Create BUP for board spec 1
#			sudo FAB=B00 BOARDID=3310 FUSELEVEL=fuselevel_production ./build_l4t_bup.sh --multi-spec jetson-tx2 mmcblk0p1
#
#		c. Append BUP for board spec 2
#			sudo FAB=A00 BOARDID=3310 FUSELEVEL=fuselevel_production ./build_l4t_bup.sh -r --multi-spec jetson-tx2 mmcblk0p1
#
#	4. Create PKC key signed BUP image:
#
#		sudo FAB=B00 BOARDID=3310 FUSELEVEL=fuselevel_production ./build_l4t_bup.sh -s <pkc_key_file> jetson-tx2 mmcblk0p1
#
#	5. Clean up BUP buffer:
#		sudo FAB=000 ./build_l4t_bup.sh -r --clean-up jetson-tx2 mmcblk0p1
#

#
# build_l4t_bup.sh supports four options and two mandatory parameters:
#
#  --clean-up
#  --multi-spec
#  -k <key_file>
#  -r reuse system.img
#  <target_board>
#  <root_dev>
#
build_l4t_bup_usage ()
{
	me="${1}"
	state="${2}"
	retval="${3}"

	if [ "${state}" = "allunknown" ]; then
		echo -e "
Usage: sudo [env={value},...} ${me} [options] <target_board> <rootdev>
  Where,
	target board: Valid target board name.
	rootdev: Proper root device.";
		echo;
	fi
	exit "${retval}"
}

#
# build_l4t_bup.sh may have two to six parameters
#
if [ $# -lt 2 -o $# -gt 6 ]; then
	build_l4t_bup_usage "${0}" "allunknown" 1
fi;

# if the user is not root, there is no point in going forward
if [ "${USER}" != "root" ]; then
	echo "${0} requires root privilege"
	exit 1
fi

BUP_DIR=$(cd `dirname $0` && pwd)
"${BUP_DIR}/flash.sh" "--no-flash" "--bup" "${@}"
exit 0
